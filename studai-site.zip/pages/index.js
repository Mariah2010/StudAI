import React, { useState } from 'react';

export default function Home() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSummarize = async () => {
    setLoading(true);
    setTimeout(() => {
      setOutput(
        "Here's your summary: " +
          input.slice(0, 150) +
          (input.length > 150 ? '...' : '')
      );
      setLoading(false);
    }, 1000);
  };

  return (
    <main className="max-w-2xl mx-auto p-6 space-y-4">
      <h1 className="text-3xl font-bold text-center">📚 StudAI</h1>
      <p className="text-center text-gray-500">
        Your AI-powered study assistant – summarize notes, prep for quizzes, and learn smarter.
      </p>
      <div className="bg-white shadow-md rounded p-4 space-y-4">
        <textarea
          rows={6}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste your notes or text here..."
          className="w-full p-2 border border-gray-300 rounded"        />
        <button
          onClick={handleSummarize}
          disabled={loading || !input}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 disabled:opacity-50"        >
          {loading ? 'Summarizing...' : 'Summarize Text'}
        </button>
        {output && (
          <div className="p-4 bg-gray-100 rounded">
            <h2 className="font-semibold mb-2">Summary:</h2>
            <p>{output}</p>
          </div>
        )}
      </div>
    </main>
  );
}